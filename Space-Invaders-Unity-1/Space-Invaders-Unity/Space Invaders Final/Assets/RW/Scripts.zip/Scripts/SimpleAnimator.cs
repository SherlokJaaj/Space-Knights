﻿using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class SimpleAnimator : MonoBehaviour
{
    public Sprite[] sprites;
    public float animationTime = 0.25f;

    private SpriteRenderer spriteRenderer;
    private float timer;
    private int currentIndex;

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        if (sprites != null && sprites.Length > 0)
            spriteRenderer.sprite = sprites[0];
    }

    private void Update()
    {
        if (sprites == null || sprites.Length == 0) return;

        timer += Time.deltaTime;
        if (timer < animationTime) return;

        spriteRenderer.sprite = sprites[currentIndex++ % sprites.Length];
        timer = 0f;
    }
}
